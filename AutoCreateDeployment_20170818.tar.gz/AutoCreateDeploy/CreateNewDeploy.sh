#!/bin/bash

hostSection="qa1"
URL=""
repositoryGit=""
repositoryPath="/opt/repos/qa"
repositoryName=""
repositoryType="base"
pathDeployment="/opt/app/nginx/html"
pathRoot="public"
pathNginxConf="/opt/app/nginx/conf"
pathFrontDeploy="/opt/app/deployment/configs/projects/qa"
pathFrontDeployMain="/opt/app/deployment/configs"
creator="system"
parentHost="qa1"
cemServer="cem.services.qa1.tff.com"
phpCommandPath="/home/commands/AutoCreateDeploy"

function usageMessage(){
    echo "
******************************************
e.g.:
    CreateNewDeploy -H qa-India -u search.services.qa-India.tff.com -g ssh://git@git.tff.bz:1158/martin.yu/search_sphinx_services.git
******************************
Arguments:
    -H <hostSection>                    required,the name of current environment
    -u <URL>                            required,the URL of current environment
    -g <repositoryGit>                  required,the URL of code repository of git
    -p <repositoryPath>                 the path of code repository on server, default: /opt/repos/qa
    -d <pathDeployment>                 the path of code in web server, default: /opt/app/nginx/html
    -r <indexPathOfNginx>               the path of index.php in web server, default: public
    -t <repositoryType>                 the type of project,such as product,base,admin,tff,finance,user,order, default:base
    -c <creator>                        creator of env deploy, default:system
    -f <parentHost>                     parent of hostSection, default:qa1
    -P <phpCommandPath>                 path of php commands, used to update main-qa.yaml and the cem->env table, default: /home/commands/auto_create_deploy
    -s <cemService>                     the URL of cem service, default: cem.services.qa1.tff.com
    -N <ConfigPath>                     the conf path of nginx, default: /opt/app/nginx/conf
    -D <deployConfigPath>               the conf path of deploy yaml file, default: /opt/app/deployment/configs/projects/qa
    -M <mainDeployConfigPath>           the conf path of deploy main-qa.yaml file, default: /opt/app/deployment/configs
******************************************"
}

while getopts ":H:u:g:p:d:r:t:i:c:f:P:s:N:D:M:" opt
do
   case $opt in
        H)
            hostSection=$OPTARG
            echo "host: $OPTARG";;
        u)
            URL=$OPTARG
            echo "URL: $OPTARG";;
        g)
            repositoryGit=$OPTARG
            echo "git: $OPTARG";;
        p)
            repositoryPath=$OPTARG
            echo "path: $OPTARG";;
        d)
            pathDeployment=$OPTARG
            echo "path of deploy: $OPTARG";;
        r)
            pathRoot=$OPTARG
            echo "path of server root: $OPTARG";;
        t)
            repositoryType=$OPTARG
            echo "path of server root: $OPTARG";;
        c)
            creator=$OPTARG
            echo "creator of env deploy: $OPTARG";;
        f)
            parentHost=$OPTARG
            echo "parentHost of host section: $OPTARG";;
        P)
            phpCommandPath=$OPTARG
            echo "Path of php Command: $OPTARG";;
        s)
            cemServer=$OPTARG
            echo "url of cem server: $OPTARG";;
        N)
            pathNginxConf=$OPTARG
            echo "the conf path of nginx: $OPTARG";;
        D)
            pathFrontDeploy=$OPTARG
            echo "the conf path of deploy yaml file: $OPTARG";;
        M)
            pathFrontDeployMain=$OPTARG
            echo "the conf path of deploy main-qa.yaml file: $OPTARG";;
        ?)
            usageMessage
            exit 1;;
   esac
done


### verify the required parameters ###
function verifyRequest(){
    error=0
    if  [ ! -n "$hostSection" ] ;then
        echo "[Error] the name of environment is required"
        error=1
    fi

    if  [ ! -n "$URL" ] ;then
        echo "[Error] URL of service is required"
        error=1
    fi

    if  [ ! -n "$repositoryGit" ] ;then
        echo "[Error] path of Git repository is required"
        error=1
    fi

    if [ ${error} == 1 ]; then
        usageMessage
        exit -1;
    fi
}

### verify the parameters first ###

verifyRequest

### get the name of code repsoitory ###
function getRepositoryName(){
    repositoryNameArr=(${repositoryGit//\// })
    repositoryNameTMP=""
    
    for repositoryNameStr in ${repositoryNameArr[@]}
    do
        repositoryNameTMP=${repositoryNameStr}
    done
    
    repositoryName=(${repositoryNameTMP//./ })
}
getRepositoryName

############ start to create deploy environments ######################

repositoryPathSection="${repositoryPath}/${hostSection}"
repositoryFilePath="${repositoryPathSection}/${repositoryName}"

if  [ -n "$pathRoot" ] ;then
    pathRoot=${pathDeployment}/${hostSection}/${repositoryName}/${pathRoot}
else
    pathRoot=${pathDeployment}/${hostSection}/${repositoryName}
fi

############ start to create config file of nginx ###############

function createConfNginxYiiadmin(){
    config_file=$1
    log_path=$2
    
    echo "server {" > ${config_file}
    echo "    server_name ${URL};" >> ${config_file}
    echo "    root ${pathRoot}/${repositoryName};" >> ${config_file}
    echo "    error_log ${log_path}/${URL}.error.log;" >> ${config_file}
    echo "    " >> ${config_file}
    echo "    include laravel;" >> ${config_file}
    echo "}" >> ${config_file}
}

function createConfNginxYiifrontend(){
    config_file=$1
    log_path=$2
    
    echo "server {" > ${config_file}
    echo "    listen 80;" >> ${config_file}
    echo "    listen 443 ssl;" >> ${config_file}
    
    echo "    server_name ${URL};" >> ${config_file}
    echo "    root ${pathRoot}/${repositoryName};" >> ${config_file}
    echo "    error_log ${log_path}/${URL}.error.log;" >> ${config_file}
    
    echo "    " >> ${config_file}
    
    echo "    location / {" >> ${config_file}
    echo "        index index.php;" >> ${config_file}
    echo "        autoindex on;" >> ${config_file}
    echo "        try_files \$uri \$uri/ /index.php?\$query_string;" >> ${config_file}
    echo "    }" >> ${config_file}
    
    echo "    " >> ${config_file}
    
    echo "    location ~ index\.php$ {" >> ${config_file}
    echo "        include fastcgi.conf;" >> ${config_file}
    echo "        fastcgi_param  SERVER_NAME \$host;" >> ${config_file}
    echo "        fastcgi_pass   127.0.0.1:9000;" >> ${config_file}
    echo "        fastcgi_param  FILE_STORAGE_PATH /opt/data;" >> ${config_file}
    echo "        fastcgi_param  FILE_STORAGE_PREFIX f1;" >> ${config_file}
    echo "        include fastcgi_params;" >> ${config_file}
    echo "        fastcgi_index  index.php;" >> ${config_file}
    echo "    }" >> ${config_file}
    
    echo "    " >> ${config_file}
    
    echo "    include ssl.inc;" >> ${config_file}
    echo "}" >> ${config_file}
    
    echo "createConfNginxYiifrontend"
}

function createConfNginxLaravel(){
    config_file=$1
    log_path=$2
    
    echo "server {" > ${config_file}
    
    if [ ${repositoryName} == "administration" ] ; then
        echo "    server_name ${URL} *.${URL};" >> ${config_file}
    else
        echo "    server_name ${URL};" >> ${config_file}
    fi
    
    echo "    root ${pathRoot};" >> ${config_file}
    echo "    error_log ${log_path}/${URL}.error.log;" >> ${config_file}
    echo "    " >> ${config_file}
    echo "    include laravel;" >> ${config_file}
    echo "}" >> ${config_file}
}

function createConfNginx(){
    config_path="${pathNginxConf}/${hostSection}.d"
    log_path="/opt/app/nginx/logs/${hostSection}"
    
    if [ ! -x "${config_path}" ]; then
        mkdir -p "${config_path}"
    fi
    
    if [ ! -x "${log_path}" ]; then
        mkdir -p "${log_path}"
    fi
    
    config_file="${config_path}/${URL}.conf"
    
    touch ${config_file}
    
    if [ ${repositoryName} == "yiiadmin" ] ; then
        createConfNginxYiiadmin ${config_file} ${log_path}
    elif [ ${repositoryName} == "yiifrontendtff" ]; then
        createConfNginxYiifrontend ${config_file} ${log_path}
    else
        createConfNginxLaravel ${config_file} ${log_path}
    fi 
            
    echo "[Nginx]create config file file new repository: ${URL}, ${config_file}"
}

############## clone code repository from git ############
function repositoryClone(){
    if [ ! -x "${repositoryPathSection}" ]; then
        mkdir -p "${repositoryPathSection}"
    fi
    
    if [ ! -d "${repositoryFilePath}" ]; then
        cd ${repositoryPathSection} && git clone ${repositoryGit} && cd -
    fi
        
    echo "[Repository] git clone the repository: ${repositoryGit}"
}

###############  create the config file for front page ############
function repositoryCreatePathFront(){
    frontProjectConfPath="${pathFrontDeploy}/${hostSection}/${repositoryType}";
    frontProjectConfFile="${frontProjectConfPath}/${repositoryName}.yaml"
    pathDeploymentRepository="${pathDeployment}/${hostSection}/${repositoryName}"
       
    if [ ! -x "${frontProjectConfPath}" ]; then
        mkdir -p "${frontProjectConfPath}"
    fi

    if [ ! -f "${frontProjectConfFile}" ]; then
        touch ${frontProjectConfFile}
    fi
    
    if [ ! -x "${pathDeploymentRepository}" ]; then
        mkdir -p "${pathDeploymentRepository}"
    fi

    echo "---" > ${frontProjectConfFile}
    echo "domain: \"http://${URL}\"" >> ${frontProjectConfFile}
    echo "name: \"${repositoryName}\"" >> ${frontProjectConfFile}
    echo "servers:" >> ${frontProjectConfFile}
    echo "    -" >> ${frontProjectConfFile}
    echo "        host: \"localhost\"" >> ${frontProjectConfFile}
    echo "        is_local: true" >> ${frontProjectConfFile}
    echo "        owner: \"apache:apache\"" >> ${frontProjectConfFile}
    echo "        command: \"ls\"" >> ${frontProjectConfFile}
    echo "repositories:" >> ${frontProjectConfFile}
    
    
    if [ ${repositoryName} == "yiiadmin" ] ; then
        echo "    ${repositoryName}:" >> ${frontProjectConfFile}
        echo "        path: \"${repositoryPath}/${hostSection}/${repositoryName}\"" >> ${frontProjectConfFile}
        echo "        deploy_path: \"${pathDeploymentRepository}/${repositoryName}\"" >> ${frontProjectConfFile}
        echo "        command: \"goconfenv-manager -e ${hostSection} -c cem.conf -p default -h ${cemServer}\"" >> ${frontProjectConfFile}
                
        echo "    yiimodel:" >> ${frontProjectConfFile}
        echo "        path: \"/opt/repos/qa/yiimodel\"" >> ${frontProjectConfFile}
        echo "        deploy_path: \"${pathDeploymentRepository}/yiimodel\"" >> ${frontProjectConfFile}
        echo "        command: \"composer install\"" >> ${frontProjectConfFile}
        
    elif [ ${repositoryName} == "yiifrontendtff" ]; then
        echo "    ${repositoryName}:" >> ${frontProjectConfFile}
        echo "        path: \"${repositoryPath}/${hostSection}/${repositoryName}\"" >> ${frontProjectConfFile}
        echo "        deploy_path: \"${pathDeploymentRepository}/${repositoryName}\"" >> ${frontProjectConfFile}
        echo "        command: \"goconfenv-manager -e ${hostSection} -c cem.conf -p default -h ${cemServer} && sed -i 's/\\\/\\\/@@UNCOMMENT@@//g' index.php\"" >> ${frontProjectConfFile}
        
        echo "    yiimodel:" >> ${frontProjectConfFile}
        echo "        path: \"/opt/repos/qa/yiimodel\"" >> ${frontProjectConfFile}
        echo "        deploy_path: \"${pathDeploymentRepository}/yiimodel\"" >> ${frontProjectConfFile}
        echo "        command: \"sed -i 's/hotel.services.tff.com/hotel.services.${hostSection}.tff.com/g'  extensions/services/config/main.php && composer install && goconfenv-manager -e ${hostSection} -c cem.conf -p default -h ${cemServer}\"" >> ${frontProjectConfFile}
    else
        echo "    ${repositoryName}:" >> ${frontProjectConfFile}
        echo "        path: \"${repositoryPath}/${hostSection}/${repositoryName}\"" >> ${frontProjectConfFile}
        echo "        deploy_path: \"${pathDeploymentRepository}\"" >> ${frontProjectConfFile}
        echo "        command: \"composer install && goconfenv-manager -e ${hostSection} -c cem.conf -p default -h ${cemServer}\"" >> ${frontProjectConfFile}
    fi 

    echo "[Repository]add path of the repository in front page: ${repositoryPath}, ${pathDeployment}"
}

function repositoryEnvCheck(){
    cemConfFile="${repositoryFilePath}/cem.conf"
    cemTemplateFIle="${repositoryFilePath}/.env.template.cem"
    
    if [ ! -f "${cemConfFile}" ]; then
        echo "[Error][${cemConfFile}] does not exist! cem.conf and .evn.template.cem are required"
        exit -1;
    fi
    
    if [ ! -f "${cemTemplateFIle}" ]; then
        echo "[Error][${cemTemplateFIle}] does not exist! cem.conf and .evn.template.cem are required"
        exit -1;
    fi
    
    echo "[Repository] check env settings"
}

function repositoryCemCheck(){
    echo "[Repository] check cem config of database"
}

createConfNginx

repositoryClone

repositoryCreatePathFront

if [ ${repositoryName} != "yiiadmin" ] && [ ${repositoryName} != "yiifrontendtff" ] ; then
    repositoryEnvCheck

    repositoryCemCheck
fi


### insert main host into env_deploy ###
if  [ -n "$phpCommandPath" ] ;then
    echo "[config] update config by php commands"
    php ${phpCommandPath}/updateEnvDeploy.php ${hostSection} ${creator} ${parentHost}
    php ${phpCommandPath}/addDeployFrontConf.php ${pathFrontDeployMain}/main-qa.yaml ${hostSection} ${repositoryType} ${repositoryName}
fi

### restart nginx and deployment service ###
/etc/init.d/nginx restart && supervisorctl restart deployment
