<?php
/**
 * Created by PhpStorm.
 * User: martin
 * Date: 2017/8/17
 * Time: 17:12
 */
return [
    "database"  =>[
        "host"      => "192.168.100.220",
        "database"  => "cem",
        "user"      => "root",
        "password"  => "P0F5rNH8qBgCnWGD",
        "table"     => "env"
    ]
];